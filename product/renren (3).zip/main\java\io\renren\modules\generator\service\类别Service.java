package io.renren.modules.generator.service;

import com.baomidou.mybatisplus.extension.service.IService;
import io.renren.common.utils.PageUtils;
import io.renren.modules.generator.entity.类别Entity;

import java.util.Map;

/**
 * ${comments}
 *
 * @author LEI
 * @email leiniu54@gmail.com
 * @date 2021-04-23 21:38:35
 */
public interface 类别Service extends IService<类别Entity> {

    PageUtils queryPage(Map<String, Object> params);
}

