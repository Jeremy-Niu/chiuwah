package io.renren.modules.generator.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * ${comments}
 * 
 * @author LEI
 * @email leiniu54@gmail.com
 * @date 2021-04-23 21:38:35
 */
@Data
@TableName("类别")
public class 类别Entity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * $column.comments
	 */
	@TableId
	private Integer 顺序;
	/**
	 * $column.comments
	 */
	private String 类别;
	/**
	 * $column.comments
	 */
	private Integer 类别层次;
	/**
	 * $column.comments
	 */
	private String 项目;

}
