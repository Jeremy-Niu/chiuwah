package io.renren.modules.generator.dao;

import io.renren.modules.generator.entity.类别Entity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * ${comments}
 * 
 * @author LEI
 * @email leiniu54@gmail.com
 * @date 2021-04-23 21:38:35
 */
@Mapper
public interface 类别Dao extends BaseMapper<类别Entity> {
	
}
