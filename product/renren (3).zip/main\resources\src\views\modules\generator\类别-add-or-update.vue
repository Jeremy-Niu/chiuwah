<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="${column.comments}" prop="类别">
      <el-input v-model="dataForm.类别" placeholder="${column.comments}"></el-input>
    </el-form-item>
    <el-form-item label="${column.comments}" prop="类别层次">
      <el-input v-model="dataForm.类别层次" placeholder="${column.comments}"></el-input>
    </el-form-item>
    <el-form-item label="${column.comments}" prop="项目">
      <el-input v-model="dataForm.项目" placeholder="${column.comments}"></el-input>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        dataForm: {
          顺序: 0,
          类别: '',
          类别层次: '',
          项目: ''
        },
        dataRule: {
          类别: [
            { required: true, message: '${column.comments}不能为空', trigger: 'blur' }
          ],
          类别层次: [
            { required: true, message: '${column.comments}不能为空', trigger: 'blur' }
          ],
          项目: [
            { required: true, message: '${column.comments}不能为空', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      init (id) {
        this.dataForm.顺序 = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.顺序) {
            this.$http({
              url: this.$http.adornUrl(`/generator/类别/info/${this.dataForm.顺序}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.类别 = data.类别.类别
                this.dataForm.类别层次 = data.类别.类别层次
                this.dataForm.项目 = data.类别.项目
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/generator/类别/${!this.dataForm.顺序 ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                '顺序': this.dataForm.顺序 || undefined,
                '类别': this.dataForm.类别,
                '类别层次': this.dataForm.类别层次,
                '项目': this.dataForm.项目
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
