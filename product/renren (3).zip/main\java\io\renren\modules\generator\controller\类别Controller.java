package io.renren.modules.generator.controller;

import java.util.Arrays;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.renren.modules.generator.entity.类别Entity;
import io.renren.modules.generator.service.类别Service;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.R;



/**
 * ${comments}
 *
 * @author LEI
 * @email leiniu54@gmail.com
 * @date 2021-04-23 21:38:35
 */
@RestController
@RequestMapping("generator/类别")
public class 类别Controller {
    @Autowired
    private 类别Service 类别Service;

    /**
     * 列表
     */
    @RequestMapping("/list")
    @RequiresPermissions("generator:类别:list")
    public R list(@RequestParam Map<String, Object> params){
        PageUtils page = 类别Service.queryPage(params);

        return R.ok().put("page", page);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{顺序}")
    @RequiresPermissions("generator:类别:info")
    public R info(@PathVariable("顺序") Integer 顺序){
		类别Entity 类别 = 类别Service.getById(顺序);

        return R.ok().put("类别", 类别);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    @RequiresPermissions("generator:类别:save")
    public R save(@RequestBody 类别Entity 类别){
		类别Service.save(类别);

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @RequiresPermissions("generator:类别:update")
    public R update(@RequestBody 类别Entity 类别){
		类别Service.updateById(类别);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @RequiresPermissions("generator:类别:delete")
    public R delete(@RequestBody Integer[] 顺序s){
		类别Service.removeByIds(Arrays.asList(顺序s));

        return R.ok();
    }

}
